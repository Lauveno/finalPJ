import chardet
import numpy as np
import pandas as pd
from django.http import JsonResponse, HttpResponse
from django.shortcuts import render, redirect
from .models import *
#--Login에 이용되는 모듈
import csv
from django.contrib.auth.hashers import make_password, check_password #비밀번호 암호화 / 패스워드 체크(db에있는거와 일치성확인)
# Create your views here.

zerowaste_df = pd.read_csv('zerowaste_fin_utf8.txt', encoding='UTF-8')
zerowaste_df = zerowaste_df.replace(np.NaN , 0)

veganfood_df = pd.read_csv('veganfood_fin.csv', encoding='UTF-8')
veganfood_df = veganfood_df.replace(np.NaN , 0)

# About page - main page
#[TEST] 로그인 할경우 UserID 뽑아보기
def about(request) :
    print('mapApp about index ~ ')
    myuser = request.session.get('user')
    if myuser :
        user = WwgUser.objects.get(user_id=myuser)
        return render(request , 'map/about.html',{'user_id':user})
    return render(request , 'map/about.html')

# Map page
def map(request) :
    print('mapApp map index ~ ')
    return render(request , 'map/map.html')

def zerowaste(request) :
    print('mapApp zerowaste index ~')
    # print(zerowaste_df.head(5))
    # print(zerowaste_df['상호명'])

    zerowasteList = []
    for idx in zerowaste_df.index :
        zerowasteList.append({
            'id' : (zerowaste_df.iloc[idx ,  : ].번호).tolist() , # numpy
            'name' : zerowaste_df.iloc[idx ,  : ].상호명 ,
            'number' : zerowaste_df.iloc[idx ,  : ].전화번호 ,
            'address' : zerowaste_df.iloc[idx ,  : ].소재지 ,
            'category' : zerowaste_df.iloc[idx ,  : ].업종 ,
            'about' : zerowaste_df.iloc[idx ,  : ].설명 ,
            'imgURL' : zerowaste_df.iloc[idx ,  : ].imgUrl ,
            'img' : zerowaste_df.iloc[idx ,  : ].jpg ,
            'lat' : (zerowaste_df.iloc[idx ,  : ].위도).tolist() , # numpy
            'lng' : (zerowaste_df.iloc[idx ,  : ].경도).tolist() # numpy
        })
    # print(zerowasteList[{'id' : '1' , 'name' : 'asdf'}])
    print('zerowasteList complete!!')
    print(zerowasteList[0])

    return JsonResponse(zerowasteList, safe=False)

# Login page
def login(request) :
    response_data={}
    if request.method == 'POST' :
        login_username=request.POST.get('user_id',None)
        login_password=request.POST.get('user_pwd',None)
        if not (login_username and login_password):
            response_data['error']="아이디와 비밀번호를 모두 입력해주세요."
        else : 
            myuser = WwgUser.objects.get(user_id=login_username) 
            #db에서 꺼내는 명령. Post로 받아온 username으로 , db의 username을 꺼내온다.
            if check_password(login_password, myuser.user_pwd):
                request.session['user'] = myuser.user_id 
                print(request.session['user'],'~~~~~~~~~~~')
                #세션도 딕셔너리 변수 사용과 똑같이 사용하면 된다.
                #세션 user라는 key에 방금 로그인한 id를 저장한것.
                return redirect('main')
            else:
                response_data['error'] = "비밀번호를 틀렸습니다."
                return render(request, 'map/login.html',response_data)        
    return render(request , 'map/login.html')

def logout(request) :
    return redirect('main')

def join(request) :
    return redirect('main')

def registerForm(request) :
    if request.method == 'POST':
        print('RegisterForm index ~ ')
        #딕셔너리 형태
        print('POST~~~~~')
        print(request.POST.get('user_id',None))
        user_id=request.POST.get('user_id',None)
        user_pwd=request.POST.get('user_pwd',None)
        user_birthyear=request.POST.get('user_birthyear',None)
        res_data = {}
        if not (user_id and user_pwd and user_birthyear) :
            res_data['error'] = "모든 값을 입력해야 합니다."
        else :
            user = WwgUser(user_id=user_id, user_pwd=make_password(user_pwd), user_birthyear=user_birthyear)
            user.save()
        return render(request, 'map/about.html', res_data) #register를 요청받으면 register.html 로 응답.
    return render(request , 'map/registerForm.html')

# csv to model 
def CsvToModel(request):
    # Zerowaste Shop loading
    path = 'C:/Users/user/PJT/WeWantGreen/rootWEB/zerowaste_fin_utf8.txt'
    file = open(path,encoding ='utf-8')
    reader = csv.reader(file)
    print('----',reader)
    z_list=[]; idx=0
    for row in reader :
        if idx != 0 :
            z_list.append(WwgZerowaste(
                index=row[0],
                name=row[1],
                number=row[2],
                address=row[3],
                category=row[4],
                about=row[5],
                imgURL=row[6],
                img=row[7],
                lat=float(row[8]),
                lng=float(row[9]),
                ))
        idx +=1
    # print(z_list)
    WwgZerowaste.objects.bulk_create(z_list)
    
    # Vegan Food Shop loading
    path = 'C:/Users/user/PJT/WeWantGreen/rootWEB/vegan_fin_utf8.txt'
    file = open(path,encoding ='utf-8')
    reader = csv.reader(file)
    print('----',reader)
    z_list=[]; idx=0
    for row in reader :
        if idx != 0 :
            z_list.append(WwgVegan(
                index=row[0],
                name=row[1],
                number=row[2],
                address=row[3],
                category=row[4],
                about=row[5],
                imgURL=row[6],
                img=row[7],
                lat=float(row[8]),
                lng=float(row[9]),
                ))
        idx +=1
    # print(z_list)
    WwgVegan.objects.bulk_create(z_list)
    return HttpResponse('create model~~~~~~')
    
# Board page
def board(request) :
    print('mapApp index ~ ')
    return render(request , 'map/board.html')


# def register(request) :
#     print('mapApp index ~ ')
#     return render(request , 'map/register.html')

